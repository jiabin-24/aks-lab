﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MathTrickCore
{
    public static class GlobalSettings
    {
        public static string CloudRoleName { get; set; } = "Backend";
    }
}
